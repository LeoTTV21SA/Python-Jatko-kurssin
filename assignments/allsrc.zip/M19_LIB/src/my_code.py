#Write your code here!
def feedback():
    # Palauta vaadittu viesti
    return 'Olen antanut palautteen.'

if __name__ == '__main__':
    print(feedback())